﻿using System;
namespace Conditional
{
    class switchstatement
    {
        public static void Main(string[] args)
        {
            int value = 2;
            switch (value)
            {
                case 1:
                    Console.WriteLine("{0} is equal to 1", value);
                    break;
                case 2:
                    Console.WriteLine("{0} is equal to 2", value);
                    break;
                case 3:
                    Console.WriteLine("{0} is equal to 3", value);
                    break;
                default:
                    Console.WriteLine("Value is not equal to  1, 2, or 3");
                    break;
            }

        }
    }
}
